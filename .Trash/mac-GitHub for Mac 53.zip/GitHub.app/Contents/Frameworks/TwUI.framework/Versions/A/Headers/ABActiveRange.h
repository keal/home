/*
 Copyright 2011 Twitter, Inc.
 
 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this work except in compliance with the License.
 You may obtain a copy of the License in the LICENSE file, or at:
 
 http://www.apache.org/licenses/LICENSE-2.0
 
 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
 */

#import <Foundation/Foundation.h>

typedef enum {
	ABActiveTextRangeFlavorUnknown = 0,
	ABActiveTextRangeFlavorURL,
	ABActiveTextRangeFlavorEmail,
	ABActiveTextRangeFlavorTwitterUsername,
	ABActiveTextRangeFlavorTwitterList,
	ABActiveTextRangeFlavorTwitterHashtag,
	ABActiveTextRangeFlavorTwitterStockSymbol,
} ABActiveTextRangeFlavor;

@protocol ABActiveTextRange <NSObject, NSCopying> // NSValue(NSRange) implicitly conforms
@property (nonatomic, readonly) NSRange rangeValue;
@property (nonatomic, readonly) ABActiveTextRangeFlavor rangeFlavor;
@property (nonatomic, readonly) NSString *displayString;
@end

@interface ABFlavoredRange : NSObject <ABActiveTextRange>
{
	NSString *displayString;
	NSRange rangeValue;
	ABActiveTextRangeFlavor rangeFlavor;
}

@property (nonatomic, assign) NSRange rangeValue;
@property (nonatomic, assign) ABActiveTextRangeFlavor rangeFlavor;

- (void)setDisplayString:(NSString *)s; // copy

@end
